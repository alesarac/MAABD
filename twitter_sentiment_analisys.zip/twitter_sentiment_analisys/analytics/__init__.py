from pathlib import Path

import pymysql


def get_project_root() -> Path:
    return str(Path(__file__).parent) + "/"

def evaluate_query(query:str, parameter=None):
    conn = pymysql.connect(host="localhost", port=3306, user="root", password="root", db="twitter")
    cur = conn.cursor(pymysql.cursors.DictCursor)
    if parameter is None:
        cur.execute(query)
    else:
        cur.execute(query,parameter)
    conn.close()
    return cur