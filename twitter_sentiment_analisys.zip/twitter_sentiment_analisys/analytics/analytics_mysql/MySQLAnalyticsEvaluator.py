from analytics.AbstractAnalyticsEvaluator import AnalyticsEvaluator
from analytics.analytics_mysql import db_mysql_queries
from init.model.Emoji import Emoji


class MySQLAnalyticsEvaluator(AnalyticsEvaluator):
    def get_name(self):
        return "mysql_db"

    def query_gol1(self, type):
        raw_result = []
        result = {}
        if type == "word":
            raw_result = db_mysql_queries.most_frequent_words()
        else:
            raw_result = db_mysql_queries.most_frequent_tokens(type)
        for row in raw_result:
            sentiment = str(row['sentiment'])
            token = str(row['code'])
            if type == "emoji":
                token = Emoji.decode_emoji(token)
            freq = int(row['freq'])
            if sentiment not in result:
               result[sentiment] = dict()
            result[sentiment][token] = freq
        return result

    def query_gol2(self):
        sentlist = []
        twitter_list = []
        resource_list = []
        result_shared_words = db_mysql_queries.resource_overlap().fetchall()
        result_N_twitter_words = db_mysql_queries.count_N_twitter_words().fetchall()
        result_N_lexical_words = db_mysql_queries.count_N_lexical_words().fetchall()
        for i in range(len(result_shared_words)):
            if result_shared_words[i]['sentiment'] != result_N_twitter_words[i]['sentiment'] or result_N_twitter_words[i]['sentiment'] != result_N_lexical_words[i]['sentiment']:
                assert("Mysql queries should retrieve data sorted by sentiment")
            sentiment =  result_shared_words[i]['sentiment']
            overlap = result_shared_words[i]['overlap']
            N_twitter = result_N_twitter_words[i]['N_twitter_words']
            N_lexical_words = result_N_lexical_words[i]['N_lex_words']
            sentlist.append(sentiment)
            twitter_list.append(round(overlap/N_twitter * 100,2))
            resource_list.append(round(overlap/N_lexical_words * 100,2))
        return sentlist,resource_list,twitter_list