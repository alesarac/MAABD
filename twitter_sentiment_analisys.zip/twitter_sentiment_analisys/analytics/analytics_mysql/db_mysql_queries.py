import pymysql

from analytics import evaluate_query


def most_frequent_words():
    """
    Calcola per ogni sentimento le parole avente un certo pos-tag
    che occorrono con maggiore frequenza
    :param threshold:
    :return:
    """
    str1 = """
    select S.sentiment as sentiment, W.lemma as code, sum(TW.freq) as freq
    from Word as W inner join TwitterWord TW on W.id = TW.idword
        inner join Message M on TW.idmessage = M.id
            inner join Sentiment S on M.idsentiment = S.id
    group by idsentiment,TW.idword
    order by sentiment,freq desc, code
    """
    return evaluate_query(str1)


def most_frequent_tokens(type):
    """
    Calcola per ogni sentimento i tocken (emoticon, hashtag, emoji)
    che occorrono con maggiore frequenza
    """
    str1 = """
    select S.sentiment as sentiment, TT.code, count(*) as freq
    from TwitterTocken TT inner join TockenMessage TM on TT.id = TM.idtocken
        inner join Message M on TM.idmessage = M.id
            inner join Sentiment S on M.idsentiment = S.id
    where TT.type = %s
    group by idsentiment,TT.id
    order by sentiment,freq desc,code
    """
    return evaluate_query(str1,type)


def resource_overlap():
    """
    Per ogni sentimento S, calcola il numero di parole condivise
    tra l'insieme X contenente tutti i lemmi di tutti i messaggi twitter relativi al sentimento S
    e l'insieme Y contenente tutti i lemmi di tutte le risorse lessicali relative al sentimento S
    :return:
    """
    str1 = """
    select S.sentiment as sentiment, count(*) as overlap
    from Word as W inner join TwitterWord TW on W.id = TW.idword
        inner join Message M on TW.idmessage = M.id
            inner join ResourceWord RW on W.id = RW.idword
            inner join LexicalResource LR on RW.idresource = LR.id
        inner join Sentiment S on M.idsentiment = S.id and LR.idsentiment = S.id
    group by S.id
    order by sentiment 
    """
    return evaluate_query(str1)


def count_N_twitter_words():
    """
    Per ogni sentimento, calcola il numero di parole presenti nel file di twitter
    :return:
    """
    str1 = """
    select S.sentiment, count(idword) as N_twitter_words
    from TwitterWord TW inner join Message M on TW.idmessage = M.id
        inner join Sentiment S on M.idsentiment = S.id
    group by S.id
    order by sentiment
    """
    return evaluate_query(str1)


def count_N_lexical_words():
    """
    Per ogni sentimento, calcola il numero di parole presenti nel file di twitter
    :return:
    """
    str1 = """
   select S.sentiment as sentiment, count(*) as N_lex_words
    from    ResourceWord RW inner join LexicalResource LR on RW.idresource = LR.id
        inner join Sentiment S on LR.idsentiment = S.id
    group by S.id
    order by sentiment
    """
    return evaluate_query(str1)





