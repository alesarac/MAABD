from analytics.AbstractAnalyticsEvaluator import AnalyticsEvaluator
from analytics.analytics_mongo import twitterCollection, lexicalResourcesCollection
from analytics.analytics_mongo.db_mongo_pipelines import generate_word_pipeline, generate_token_pipeline, \
    generate_count_words_pipeline, generate_percentage_pipeline


class MongoAnalyticsEvaluator(AnalyticsEvaluator):

    def get_name(self):
        return "mongo_db"

    def query_gol1(self, type):
        raw_result = []
        result = dict()
        list_name = type + "s"
        if type == "word":
            raw_result = list(twitterCollection.aggregate(generate_word_pipeline()))
        else:
            raw_result = list(twitterCollection.aggregate(generate_token_pipeline(list_name)))
            print(raw_result)
        for element in raw_result:
            sentiment = element['_id']
            if sentiment not in result:
                result[sentiment] = dict()
            for i in range(len(element[list_name])):
                token = element[list_name][i]
                freq = element[list_name][i]['freq']
                result[sentiment][token['lemma']] = token['freq']
        return result

    def query_gol2(self):
        list_perc_presence_lex_res = []
        list_perc_presence_twitter = []
        sentlist = lexicalResourcesCollection.distinct("sentiment")#{}, {"sentiment": 1, "_id": 0}))
        print(sentlist)
        for sent in sentlist:
            result = list(twitterCollection.aggregate(generate_count_words_pipeline(sent)))
            countWords = result[0]['countWords']
            perc_result = (list(twitterCollection.aggregate(generate_percentage_pipeline(sentiment=sent, countwords=countWords))))
            tot_word_lex_res = 0
            tot_shared_word = 0
            for elem in perc_result:
                tot_word_lex_res += elem["perc_presence_lex_res"][1]
                tot_shared_word += elem["perc_presence_lex_res"][0]
            perc_presence_lex_res = round((tot_shared_word / tot_word_lex_res)*100,2)
            perc_presence_twitter = round((tot_shared_word / countWords)*100,2)
            list_perc_presence_lex_res.append(perc_presence_lex_res)
            list_perc_presence_twitter.append(perc_presence_twitter)
        return sentlist, list_perc_presence_lex_res, list_perc_presence_twitter