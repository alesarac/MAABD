import pymongo as pymongo

mongoClient = pymongo.MongoClient(
    "mongodb+srv://diego:root@cluster0.rjmoxp9.mongodb.net/?retryWrites=true&w=majority")
mydb = mongoClient["twitter_sentiment_analysis"]
# le collezzioni
twitterCollection = mydb["Twitter"]
lexicalResourcesWordsCollection = mydb["LexResourcesWords"]
lexicalResourcesCollection = mydb["LexResources"]