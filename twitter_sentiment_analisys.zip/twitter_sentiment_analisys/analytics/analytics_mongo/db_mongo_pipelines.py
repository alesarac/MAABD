def generate_word_pipeline():
    return [
      {
        "$group": {
          "_id": "$sentiment",
          "words_list": {
            "$push": "$words"
          },

        }
      },
      {
        "$project": {
          "words": {
            "$reduce": {
              "input": "$words_list",
              "initialValue": [],
              "in": {
                "$concatArrays": [
                  "$$value",
                  "$$this"
                ]
              }
            }
          }
        }
      },
      {
        "$unwind": "$words"
      },
      {
        "$group": {
          "_id": {
            "sentiment": "$_id",
            "lemma": "$words.lemma"
          },
          "count": {
            "$sum": {
              "$toInt": "$words.freq"
            }
          }
        }
      },
      {
        "$sort": {
          "count": -1
        }
      },
      {
        "$group": {
          "_id": "$_id.sentiment",
          "words": {
            "$push": {
              "lemma": "$_id.lemma",
              "freq": "$count"
            }
          }
        }
      },
        {
            "$sort": {
                "sentiment": 1
            }
        }
    ]


def generate_token_pipeline(list_name):
    return [
        {
            "$group": {
                "_id": "$sentiment",
                "list": {
                    "$push": "$" + list_name
                },

            }
        },
        {
            "$project": {
                list_name: {
                    "$reduce": {
                        "input": "$list",
                        "initialValue": [],
                        "in": {
                            "$concatArrays": [
                                "$$value",
                                "$$this"
                            ]
                        }
                    }
                }
            }
        },
        {
            "$unwind": "$" + list_name
        },
        {
            "$group": {
                "_id": {
                    "sentiment": "$_id",
                    list_name[:-1]: "$" + list_name
                },
                "count": {
                    "$sum": 1
                }
            }
        },
        {
            "$sort": {
                "count": -1
            }
        },
        {
            "$group": {
                "_id": "$_id.sentiment",
                list_name: {
                    "$push": {
                        "lemma":  "$_id." + list_name[:-1],
                        #list_name[:-1]: "$_id." + list_name[:-1],
                        "freq": "$count"
                    }
                }
            }
        },
        {
            "$sort": {
                "sentiment": 1
            }
        }

    ]

def generate_count_words_pipeline(sentiment):
     return [
        {"$match": {"sentiment": sentiment}},
        {"$project": {
            "_id": 0,
            "sentiment": 1,
            "words": {"$size": "$words"}
        }},
        {"$group": {"_id": "$sentiment", "countWords": {"$sum": "$words"}}}
    ]


def generate_percentage_pipeline(sentiment, countwords):
    return [
            #seleziona solo i records di un certo sentimento
            {"$match": {"sentiment": sentiment}},
            #project i soli gli attributi
            {"$project": {
                "_id": 0,
                "words.lemma": 1,
                "words.in_lex_resources": 1
            }},
            #crea un documento per ogni parola
            {"$unwind": "$words"},
            #crea un documento per ogni elemento dell'array
            {"$unwind": "$words.in_lex_resources"},
            #conta il numero di parole condivise in ogni file delle risorse lessicografiche
            {"$group": {"_id": "$words.in_lex_resources", "countSharedWords": { "$sum": 1 }}},
            #left outer join con collection lexresources sulla base del campo sentimento
            {"$lookup": {
                "from": "LexResources",
                "localField": "_id",
                "foreignField": "id",
                "as": "RefResource" #l'oggetto risorsa lessicografica con cui è avvenuto il match
            }},

            {"$project": {
                "_id": 0,
                "resourceName": "$_id",
                "countSharedWords": 1,   #numero di parole condivise in ogni file delle risorse lessicografiche
                "countResourcesWords": "$RefResource.totNumberofWords"  #numero totale di parole risorsa lessicografica
            }},
            {"$unwind": "$countResourcesWords"}, #sostiusce array singleton con attributo chiave-valore
            {"$addFields": {"totalWordsEmotion" : countwords}},  #aggiunge campo numero parole del file twitter
            {"$project": {
            "resourceName": 1,
            "perc_presence_lex_res": [ "$countSharedWords", "$countResourcesWords" ],
            "perc_presence_twitter": [ "$countSharedWords", "$totalWordsEmotion" ]}}
        ]

    """ 

     return [
        {
            "$group": {
                "_id": "$sentiment",
                "list": {
                    "$push": "S" + list_name
                },

            }
        },
        {
            "$project": {
                list_name: {
                    "$reduce": {
                        "input": "$list",
                        "initialValue": [],
                        "in": {
                            "$concatArrays": [
                                "$$value",
                                "$$this"
                            ]
                        }
                    }
                }
            }
        },
        {
            "$unwind": list_name
        },
        {
            "$group": {
                "_id": {
                    "sentiment": "$_id",
                    "list": list_name
                },
                "count": {
                    "$sum": 1
                }
            }
        },
        {
            "$sort": {
                "count": -1
            }
        },
        {
            "$group": {
                "_id": "$_id.sentiment",
                "hashtags": {
                    "$push": {
                        "list": "$_id" + list_name[:-1],
                        "freq": "$count"
                    }
                }
            }
        }
    ]

    """