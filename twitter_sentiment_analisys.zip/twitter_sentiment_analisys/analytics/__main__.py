from analytics.analytics_mongo.MongoAnalyticsEvaluator import MongoAnalyticsEvaluator
from analytics.analytics_mysql.MySQLAnalyticsEvaluator import MySQLAnalyticsEvaluator
from analytics.analytics_mysql.db_mysql_queries import most_frequent_words

def main():
    evaluators = [MongoAnalyticsEvaluator()] #MySQLAnalyticsEvaluator(),]
    for evaluator in evaluators:
        #evaluator.execute_query_gol1(top=5)
        evaluator.execute_query_gol2()

if __name__ == '__main__':
    # execute only if run as the entry point into the program
    main()

