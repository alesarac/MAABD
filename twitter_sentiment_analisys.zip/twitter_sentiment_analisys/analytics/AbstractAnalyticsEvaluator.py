import json
import time
from abc import ABC, abstractmethod
from typing import List
from wordcloud import WordCloud
from analytics import get_project_root
import pandas as pd
import matplotlib.pyplot as plt



class AnalyticsEvaluator(ABC):
    """
    Abstract class defining the skeleton of analytics in terms of a number of high-level steps.
    These steps are themselves implemented by additional helper methods in the same class as the template method.
    The helper methods may be either abstract methods, in which case subclasses are required to provide concrete implementations,
    """

    @abstractmethod
    def get_name(self):
        """
        :return: name of methodology
        """
    @abstractmethod
    def query_gol1(self, type):
        """
        Calcola per ogni sentimento la frequenza di occrrenza delle parole
        return: lista
        :param type: in range {word,emoji,emoticon,hashtag}
        :return: dizionario a 2 livelli della forma sentimento->tocken->frequenza
        """

    @abstractmethod
    def query_gol2(self):
        """
        Calcola per ogni sentimento le due percentuali richieste nel calcolo della sovrapposizione
        di parole tra messaggi twitter e risorse lessicali
        :return:
                 sentlist containing list of sentiments
                 list1 containing percentage with respect to lexical words,
                 list2 containing percentages with respect to twitter
        """

    def __build_wordCloud(self, dict1, type, top) :
        """
        Build worcloud and print to a directory
        :param list1: values should be sorted according to Sentiment value
        :param type: in range {word,emoji,emoticon,hashtag}
        :param top: number of top words to display
        :return:
        """
        for sentiment in dict1.keys():
                dict_sentiment = dict1[sentiment]
                #get top elements for the particular sentiment
                top_words = dict(sorted(dict_sentiment.items(), key=lambda x: x[1], reverse=True)[:top])
                print(sentiment + " -> " + str(top_words))
                wc = None
                if type == "emoji":
                    path_font_emoji = get_project_root() + "resources/font/Symbola.otf"
                    wc = WordCloud(background_color='white', width=1920, height=1080, margin=2, font_path=path_font_emoji)
                else:
                    wc = WordCloud(background_color='white', width = 1920, height=1080, margin=2)
                wc.fit_words(top_words)
                wc.to_file(get_project_root()+"output/wordcloud/"+self.get_name()+"/"+ type + "/" + sentiment+"_"+type+".png")


    def execute_query_gol1(self, top=5):
        tocken_types = ['word','hashtag','emoticon','emoji']
        for type in tocken_types:
            start = time.time()
            dict1 = self.query_gol1(type)
            interval = time.time() - start
            print(f" {self.get_name().upper()} ha richiesto per il conteggio di {type} all'incirca {str(round(interval, 2))} secondi")
            self.__build_wordCloud(dict1,type,top)

    def execute_query_gol2(self):
        start = time.time()
        sentlist,list_perc_presence_lex_res,list_perc_presence_twitter = self.query_gol2()
        interval = time.time() - start
        print(
            f" {self.get_name().upper()} ha richiesto per il calcolo delle percentuali"
            f" inerenti la sovrapposizione tra messaggi Twitter e risorse lessicali all'incirca {str(round(interval, 2))} secondi")
        # Create the pandas DataFrame
        df = pd.DataFrame({'perc_presence_lex_res': list_perc_presence_lex_res,
                           'perc_presence_twitter': list_perc_presence_twitter}, index=sentlist)
        # Creazione istogramma per presenza parole nelle risorse lessicali
        ax = df.plot.bar(figsize=(15, 5))
        path_histogram = get_project_root()+"output/histogram/"+self.get_name()+ "/histograms_complete.png"
        plt.savefig(path_histogram)
        plt.show()
        # Create the pandas DataFrame
        df1 = pd.DataFrame({'perc_presence_lex_res': [str(x) + "%" for x in list_perc_presence_lex_res],
                           'perc_presence_twitter': [str(x) + "%" for x in list_perc_presence_twitter]}, index=sentlist)
        print(df1)