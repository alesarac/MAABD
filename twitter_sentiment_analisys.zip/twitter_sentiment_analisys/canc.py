import torch
torch.device("mps")
print(torch.cuda.is_available())

print(torch.backends.mps.is_available())# this ensures that the current current PyTorch installation was built with MPS activated.
print(torch.backends.mps.is_built())