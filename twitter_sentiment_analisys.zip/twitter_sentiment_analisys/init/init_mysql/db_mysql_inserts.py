import pymysql
from sqlalchemy import exists, inspect
from sqlalchemy.orm import state

from init import get_project_root
from init.init_mysql import Session
from init.model.Emoji import Emoji
from init.model.Emoticon import Emoticon
from init.model.Hashtag import Hashtag
from init.model.LexicalResource import LexicalResource
from init.model.Message import Message
from init.model.Sentiment import Sentiment
from init.model.TwitterWord import TwitterWord
from init.model.Word import Word


def clean_DB():
    conn = pymysql.connect(host="localhost", port=3306, user="root", db="twitter")
    cur = conn.cursor()
    query1 = "DELETE from TwitterWord"
    query2 =  "ALTER TABLE TwitterWord AUTO_INCREMENT = 1"
    query3 = "DELETE from TwitterWord"
    query4 = "ALTER TABLE TwitterWord AUTO_INCREMENT = 1"
    query5 = "DELETE from ResourceWord"
    query6 = "ALTER TABLE ResourceWord AUTO_INCREMENT = 1"
    query7 = "DELETE from Word"
    query8 = "ALTER TABLE Word AUTO_INCREMENT = 1"
    query9 = "DELETE from TockenMessage"
    query10 = "ALTER TABLE TockenMessage AUTO_INCREMENT = 1"
    query11 = "DELETE from TwitterTocken"
    query12 = "ALTER TABLE TwitterTocken AUTO_INCREMENT = 1"
    query13 = "DELETE from LexicalResource"
    query14 = "ALTER TABLE LexicalResource AUTO_INCREMENT = 1"
    query15 = "DELETE from Message"
    query16 = "ALTER TABLE Message AUTO_INCREMENT = 1"
    query17 = "DELETE from Sentiment"
    query18 = "ALTER TABLE Sentiment AUTO_INCREMENT = 1"
    queries = [query1,query2,query3,query4,query5
               ,query6,query7,query8,query9,query10
               ,query11,query12,query13,query14,query15
               ,query16,query17,query18]
    for query in queries:
        cur.execute(query)
    conn.close()


def insert_sentiment(session,sentiment):
    session.add(sentiment)
    session.flush

def insert_lexical_resource(session, resource):
    session.add(resource)
    session.flush

def insert_lemma_in_lexical_resource(session, resource:LexicalResource, lemma):
    word = session.query(Word).filter(Word.lemma == lemma).first()
    if word is None:
        word = Word(lemma=lemma)
    resource.words.append(word)

def insert_tweet(session:Session, sentiment, count_message, words, emojiList, hashtagList, emoticonList):
    try:
        message = Message(countmsg=count_message, sentiment=sentiment)

        for word_tuple in words:
            lemma = word_tuple[0]
            pos = word_tuple[1]
            freq = word_tuple[2]
            word = session.query(Word).filter(Word.lemma == lemma).first()
            if word is None:
                word = Word(lemma=lemma)
            message.words.append(TwitterWord(word=word, pos=pos, freq=freq))  # object in persistent state

        for emoji_element in emojiList:
            emoji_code = Emoji.encode_emoji(emoji_element)
            emoji = session.query(Emoji).filter(Emoji.code == emoji_code).first()
            if emoji is None:
                emoji = Emoji(code=emoji_code)
            message.tockens.append(emoji)

        for emoticon_code in emoticonList:
            emoticon = session.query(Emoticon).filter(Emoticon.code == emoticon_code).first()
            if emoticon is None:
                emoticon = Emoticon(code=emoticon_code)
            message.tockens.append(emoticon)

        for hashtag_code in hashtagList:
            hashtag = session.query(Hashtag).filter(Hashtag.code == hashtag_code).first()
            if hashtag is None:
                hashtag = Hashtag(code=hashtag_code)
            message.tockens.append(hashtag)

        session.add(message)
        return True
    except:
        log = "Unable to save message: ",str(count_message), " of sentiment ", str(sentiment)
        print(log)
        path = get_project_root() + "/init_mysql/unsaved_tweets.txt"
        with open(path, 'a') as fd:
            fd.write(f'\n{log}')
        fd.close()
        return False


