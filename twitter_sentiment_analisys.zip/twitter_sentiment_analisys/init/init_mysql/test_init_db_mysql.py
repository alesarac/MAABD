from init.init_mysql import Session
from init.init_mysql.db_mysql_inserts import clean_DB
from init.model.Emoji import Emoji
from init.model.Emoticon import Emoticon
from init.model.Hashtag import Hashtag
from init.model.Message import Message
from init.model.Sentiment import Sentiment
from init.model.TwitterTocken import TwitterTocken
from init.model.TwitterWord import TwitterWord
from init.model.Word import Word

def test_detached_state():
    clean_DB()
    session = Session()
    sentiment = Sentiment(sentiment="Anger")
    session.add(sentiment)
    print(sentiment.id)
    session.flush()
    print(sentiment.id)
    session.close()


def test_nested_insert():
    clean_DB()
    session = Session()
    sentiment = Sentiment(sentiment="Anger")
    message1 = Message(countmsg=1)
    message1.tockens = [Emoticon(code=":)"), Hashtag(code="#cantwait")]
    message1.words = [TwitterWord(word=Word(lemma="report"), pos="NN"),
                      TwitterWord(word=Word(lemma="enemy"), pos="NN"), TwitterWord(word=Word(lemma="kill"), pos="VERB")]
    message2 = Message(countmsg=1)
    message2.tockens = []
    sentiment.tweets.append(message1)
    session.add(sentiment)
    print(message1)
    session.commit()
    session.close()


def test_pending_istance():
    clean_DB()
    session = Session()
    sentiment = Sentiment(sentiment="Anger")
    message1 = Message(countmsg=1, sentiment=sentiment)
    emoji = Emoji()
    emoji.encode_emoji('😒')
    message1.tockens = [Emoticon(code=":)"), Hashtag(code="#cantwait"), emoji]
    message1.words = [TwitterWord(word=Word(lemma="report"), pos="NOUN"),
                      TwitterWord(word=Word(lemma="enemy"), pos="NN"),
                      TwitterWord(Word(lemma="kill"), pos="VERB")]
    session.add(message1)
    word = session.query(Word).filter(Word.lemma == "report").first()
    print(word)
    if word is None:
        word = Word(lemma="report")
    tocken = session.query(TwitterTocken).filter(TwitterTocken.code == emoji.code,
                                                 TwitterTocken.type == "emoji").first()  # object in persistent state
    if tocken is None:
        tocken = Emoji()
        emoji.encode_emoji('😒')
    message2 = Message(countmsg=2, sentiment=sentiment)
    message2.words = [TwitterWord(word=word, pos="NOUN")]
    message2.tockens = [tocken]
    #message2.tockens.append(tocken)
    session.add(message2)
    session.commit()
    session.close()


def test_emoji():
    session = Session()
    emoji = Emoji()
    emoji.encode_emoji('😄') #😒
    tocken = session.query(TwitterTocken).filter(TwitterTocken.code == emoji.code,
                                                 TwitterTocken.type == "emoji").first()  # object in persistent state
    if tocken is not None:
        print(tocken.decode_emoji())
    session.close()

#test_detached_state()
test_nested_insert()
#test_pending_istance()
#test_emoji()
