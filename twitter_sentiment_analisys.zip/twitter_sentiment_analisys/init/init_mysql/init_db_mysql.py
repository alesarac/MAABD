import codecs
import os

from init import get_project_root
from init.init_mysql import Session,  db_mysql_inserts
from init.init_mysql.db_mysql_inserts import insert_sentiment, clean_DB, insert_lemma_in_lexical_resource, \
    insert_lexical_resource, insert_tweet
from init.model.LexicalResource import LexicalResource
from init.model.Sentiment import Sentiment
from init.nlp.StanfordEvaluator import StanfordEvaluator
from init.nlp.cleantext.TwitterMessageCleaner import TwitterMsgCleaner

#TEST_N = 100 #max number of tweets to examine at test time
def get_sentiment(str):
    array_els = str.split("_")
    if len(array_els) >= 3:
        return Sentiment(sentiment=(str.split("_")[2]))  # prendo il sentimento dal nome del file

def tweets_management(session, file_path, evaluator,  sentiment_obj):
    with codecs.open(file_path, 'r', encoding='utf8') as data:
        cont_msg = 1
        for raw_message in data.readlines():
            # pipeline è un metodo polimorfico! Vedi classe astratta NLPEvaluator
            words, emojiList, hashtagList, emoticonList = evaluator.pipeline(raw_message)
            print("id:", cont_msg, " :", raw_message, words, list(emoticonList), list(emojiList), list(hashtagList))
            # print(raw_message + str(message) + "\n" )
            if insert_tweet(session, sentiment_obj, cont_msg, words, emojiList, hashtagList, emoticonList):
                print("INSERTED!\n")
            else:
                print("ERROR!\n")
            cont_msg += 1
            #if cont_msg > TEST_N:  # Da rimuovere al termine dei test
            #    break
    data.close()
def lexical_resources_management(session, evaluator,  sentiment_obj):
    sentiment_name = sentiment_obj.sentiment
    print(sentiment_name)
    path = get_project_root() + "/nlp/cleantext/resources/lexical_resources/" + str(sentiment_name) +"/"
    for file in os.listdir(path):
        #name = file.split("_")[0]  # estrae dal file EMOSn, NRC o sentisense
        lexical_resource = LexicalResource(filename=file, sentiment=sentiment_obj)
        insert_lexical_resource(session, lexical_resource)
        current_file = open(path + file, 'r', encoding="utf8")
        for line in current_file:
            line = line.strip()
            if not "_" in line:
                result = evaluator.pipeline(line)[0]
                lemma = result[0]
                #print(lemma)
                insert_lemma_in_lexical_resource(session, lexical_resource, lemma)
        print(file, " inserted!")
        current_file.close()


def init_process(test_mode = True):
    session = Session()
    path_tweets = ""
    if test_mode:
        path_tweets = get_project_root() + "/nlp/cleantext/resources/twitter_prove"
    else:
        path_tweets = get_project_root() + "/nlp/cleantext/resources/twitter"
    try:
        #clean_DB() #clean all the content of DB for initialization
        tweet_evaluator = StanfordEvaluator(cleaner=TwitterMsgCleaner())
        resource_evaluator = StanfordEvaluator(lemmatization=True, tokenize=False, pos_tag=False)
        for file in os.listdir(path_tweets):
            sentiment = get_sentiment(file)
            if sentiment is None:
                continue
            print("------SENTIMENT: ", sentiment.sentiment, " ------------------------------------\n")
            insert_sentiment(session,sentiment)
            tweets_management(session, os.path.join(path_tweets, file), tweet_evaluator,  sentiment)
            lexical_resources_management(session, resource_evaluator, sentiment)
        session.commit()
    except:
        print("Transazione abortita")
        session.rollback()
        raise
    finally:
        session.close()

