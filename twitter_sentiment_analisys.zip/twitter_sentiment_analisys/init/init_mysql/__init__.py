from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


engine = create_engine('mysql+pymysql://root:'
                       '@localhost/twitter?charset=utf8mb4', pool_recycle=3600, echo=False)
Session = sessionmaker(bind=engine,autoflush=True)
session = Session()
