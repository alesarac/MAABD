import codecs
import os

from init import get_project_root
from init.init_mongodb import lexicalResourcesWordsCollection, lexicalResourcesCollection
from init.init_mongodb.db_mongo_utils import load_tweet, aggregazione_risorse_lessicali
from init.nlp.StanfordEvaluator import StanfordEvaluator
from init.nlp.cleantext.TwitterMessageCleaner import TwitterMsgCleaner


sentiment = "anger"

def load_lexicalRes(sent):
    '''
    Questo metodo viene chiamato per primo e quindi prima di inserire i tweet del sentimento corrente.
    Quindi se sono su "anger", prima di trattare i tweet chiamo questo metodo che modella e carica le risorse Lessicali
    e poi posso andare a processare i tweet di quel sentimento in questione

    Prende in INPUT solo il sentimento in questione
    '''
    #Inserimento collezzione Risorse Lessicali per sentimento
    lista_lemma_files,file_name_countWords=aggregazione_risorse_lessicali(sent)

    for element in lista_lemma_files:
        document={}
        document["lemma"]=element[0]
        document["sentiment"]=sent
        document["resources"]=element[1]
        #inserimento
        lexicalResourcesWordsCollection.insert_one(document)
    for name_count in file_name_countWords:
        document={}
        document["id"]=name_count[0]
        document["sentiment"]=sent
        document["totNumberofWords"]=name_count[1]
        #inserimento
        lexicalResourcesCollection.insert_one(document)
    print("Inserite risorse lessicali per sentimento ", sent)

def init_process(test_mode = True):
    if test_mode:
        path_tweets = get_project_root() + "/nlp/cleantext/resources/twitter_prove"
    else:
        path_tweets = get_project_root() + "/nlp/cleantext/resources/twitter"    # ciclo i file dei tweets di ogni sentimento
    tweet_evaluator = StanfordEvaluator(cleaner=TwitterMsgCleaner())
    for file in os.listdir(path_tweets):
        with codecs.open(os.path.join(path_tweets, file), 'r', encoding='utf8') as data:
            array_els = file.split("_")
            if len(array_els) >= 3:
                sent = (file.split("_")[2])
            else:
                continue
            load_lexicalRes(sent)
            count_row=1
            for line in data.readlines():
                words, emojiList, hashtagList, emoticonList = tweet_evaluator.pipeline(line)
                #NOTA: words è una lista in cui ciascun elemento assume la forma di una tupla
                #(lemma, pos, freq)
                # carico su Mongo una riga di tweet per volta
                list1 = [{'lemma':tuple_word[0], 'POS':tuple_word[1], 'freq':tuple_word[2] }  for tuple_word in words]
                load_tweet(count_row, sent, list1, hashtagList, emojiList, emoticonList)
                count_row+=1
