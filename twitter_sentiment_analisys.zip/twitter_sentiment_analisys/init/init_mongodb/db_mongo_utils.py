import os

from init import get_project_root
from init.init_mongodb import lexicalResourcesWordsCollection, twitterCollection


def aggregazione_risorse_lessicali(sent):
    resourceEmoSN = []
    resourceNRC = []
    resourceSentisense = []
    file_name_countWords = []
    pathRisorse = get_project_root() + "/nlp/cleantext/resources/lexical_resources/" + str(sent) +"/"

    # per ogni file presente nelle cartelle sentimento (Anger, Anticipation, ecc...)
    for file in os.listdir(pathRisorse): # + "\\" + sent):
        path_of_file = pathRisorse + "/" + file  #+ "\\" + sent + "\\" + file
        column = file.split("_")[0]  # estrae dal file EMOSn, NRC o sentisense
        current_file = open(path_of_file, 'r', encoding="utf8")

        # ciclo per creare le tre liste di lemma per i tre diversi nomi di file
        # andando però a NON prendere le parole composte, cioè quelle con gli underscore (come richiesto dai requisiti)
        for line in current_file:
            riga = line.strip()
            if not "_" in riga:
                if column == "EmoSN":
                    resourceEmoSN.append(riga)
                elif column == "NRC":
                    resourceNRC.append(riga)
                elif column == "sentisense":
                    resourceSentisense.append(riga)
        current_file.close()

    # parte per inserire il nome del file e il numero di parole di quel file
    # servirà per la collezzione "LexResources"
    temp_file_list = []
    if resourceEmoSN:
        temp_file_list.append("EmoSN_" + sent + ".txt")
        temp_file_list.append(len(resourceEmoSN))
        file_name_countWords.append(temp_file_list)
        temp_file_list = []
    if resourceNRC:
        temp_file_list.append("NRC_" + sent + ".txt")
        temp_file_list.append(len(resourceNRC))
        file_name_countWords.append(temp_file_list)
        temp_file_list = []
    if resourceSentisense:
        temp_file_list.append("sentisense_" + sent + ".txt")
        temp_file_list.append(len(resourceSentisense))
        file_name_countWords.append(temp_file_list)
        temp_file_list = []

    # lista finale che contiene tutti i lemmi del sentimento seguito da una lista annidata che contiene "file_presence" del lemma
    lista_output = []

    for lemma in resourceEmoSN + resourceNRC + resourceSentisense:
        temp_list = []  # lista temporanea per creare ogni volta l'oggetto: ["lemma", ["nome_file",...]]
        file_presence = []  # lista che contiene i nomi dei file per la quale il lemma in questione è presente

        if lemma in resourceEmoSN:
            file_presence.append("EmoSN_" + sent + ".txt")
        if lemma in resourceNRC:
            file_presence.append("NRC_" + sent + ".txt")
        if lemma in resourceSentisense:
            file_presence.append("sentisense_" + sent + ".txt")

        temp_list.append(lemma)
        temp_list.append(file_presence)
        lista_output.append(temp_list)

    return lista_output, file_name_countWords


def load_tweet(row,sent,tweet_freq_count,hashtags,emoji,emoticons):
    '''
    # Questo metodo viene chiamato dopo aver modellato e inserito sul DB le risorse lessicali del sentimento che sto trattando

    # Prende in INPUT :
        row: sarebbe la riga del tweet che sto trattando per il sentimento in questione
        sent: sarebbe il sentimento in questione
        tweet_freq_count: questa è la struttura che contiene la tripletta: (lemma, POS, freq)
        hashtags: è la lista di hashtag della riga in questione
        emoji: è la lista delle emoji della riga in questione
        emoticons: è la lista delle emoticons della riga in questione

    ESEMPIO:
        row: 1
        sent: "anger"
        tweet_freq_count: [{'lemma': 'god', 'POS': 'NN', 'freq': 1}, {'lemma': 'spell', 'POS': 'NN', 'freq': 1}, {'lemma': 'fired', 'POS': 'VBD', 'freq': 1}, ecc..]
        hashtags: ['andyou', 'fuckyou', 'sluts', ecc...]
        emoji: ['😡', '😑', ecc...]
        emoticons: ['>.<', ecc...]
    '''

    #carico su MongoDB ogni singola riga (cioè ogni singolo tweet)
    document_tweet = {}

    document_tweet["sentiment"]=sent
    document_tweet["doc_number"]=row

    #indico se un lemma è presente nelle risorse (e quali risorse) del sentimento in questione
    for i in range(len(tweet_freq_count)):
        id=0
        for itm in lexicalResourcesWordsCollection.find({"lemma":tweet_freq_count[i]["lemma"],"sentiment":sent}):
            id=itm.get('_id')
            # print(f"lemma: {tweet_freq_count[i]['lemma']}")
            if id !=0:
                #tweet_freq_count[i]["in_lex_resources"]= {"$ref": "LexResourcesWords", "$id": id}
                #tweet_freq_count[i]["in_lex_resources"]= {"ref": "LexResourcesWords", "id": id}
                tweet_freq_count[i]["in_lex_resources"]= itm.get('resources')

    document_tweet["words"]=tweet_freq_count

    #se le liste non sono vuote allora inserisco (la coppia tocken-frequenza), altrimenti nulla
    if hashtags:
        document_tweet["hashtags"]=[item for item in set(hashtags)]
    if emoji:
        document_tweet["emojis"]=[item for item in set(emoji)]
    if emoticons:
        document_tweet["emoticons"]=[item for item in set(emoticons)]

    #inserimento
    twitterCollection.insert_one(document_tweet)
    print(f" Inserita riga-{row} in sentimento {sent}")