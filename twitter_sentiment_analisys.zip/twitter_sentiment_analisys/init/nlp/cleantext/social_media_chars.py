#ricordarsi di dire che abbiamo aggiunto delle emoticon che non c'erano nella lista passsata dalla meo, tipo >_< ma ce ne sono altre da menzionare
##################### EMOTICONS #####################
completeEmoticonsList = [':‑)',':)',':-]',':]',':->',':>','8-)','8)',':-}',':}',':o)',':c)',':^)','=]','=)',':‑D',':D','8‑D','8D','=D','=3','B^D','c:',
'C:','x‑D','xD','X‑D','XD',':-))',':‑(',':(',':‑c',':c',':‑<',':<',':‑[',':[',':-||','>:[',':{',':@',':('',;(',":'‑(",":'(",':=(',":'‑)",":')",
':"D',"D‑':",'D:<','D:','D8','D;','D=','DX',':‑O',':O',':‑o',':o',':-0','8‑0','>:O','=O','=o','=0',':-3',':3','=3','x3','X3','>:3',':-*',
':*',':×',';‑)',';)','*-)','*)',';‑]',';]',';^)',';>',':‑,',';D',';3',':‑P',':P','X‑P','XP','x‑p','xp',':‑p',':p',':‑Þ',':Þ',':‑þ',':þ',':‑b',':b',
'd:','=p','>:P',':-/',':/',':‑.',">:/",'=/',':L','=L',':S',':‑|',':|',':$','://)','://3',':‑X',':X',':‑#',':#',':‑&',':&','O:‑)','O:)','0:‑3'
,'0:3','0:‑)','0:)','0;^)','>:‑)','>:)','}:‑)','}:)','3:‑)','3:)','>;‑)','>;)','>:3',';3','|;‑)','|‑O','B-)',':‑J','#‑)','%‑)','%)',':‑###..'
,':###..','<:‑|',"',:-|","',:-l",':E','8-X','8=X','x-3','x=3','~:>','v.v','._.','._.;','QQ  ','qq','Qq','X_X','x_x','+_+','X_x','x_X'
'<_<','>_>','<.<','>.>','O_O','o_o','O-O','o‑o','O_o','o_O','>.<','>_<','^5','o/\o','>_>^ ^<_<','V.v.V','V=(° °)=V','(^^^)','(::[]::)',
'(o)(o)','( • )( • )','[̲̅$̲̅(̲̅1̲̅)̲̅$̲̅]','[̲̅$̲̅(̲̅5̲̅)̲̅$̲̅]','[̲̅$̲̅(̲̅10)̲̅$̲̅]','[̲̅$̲̅(̲̅100)̲̅$̲̅]','( ͡° ͜ʖ ͡°)','ヽ༼ຈل͜ຈ༽ﾉ','(๑ˇεˇ๑)','(◕‿◕✿)','( ༎ຶ ۝ ༎ຶ )','(=ʘᆽʘ=)∫','ʕ •ᴥ•ʔ',
'(>_<)','(>_<)>','(>w<)',"(';')",'(^_^;)','(-_-;)','(~_~;)','(・.・;)','(・_・;)','^^;','(・・;)','^_^;','(#^.^#)'
,'(^^;)','(⁄ ⁄•⁄ω⁄•⁄ ⁄)','(-.-)y-°°°','(^.^)y-.o○','(-_-)zzz','(^_-)-☆','(^_-)','((+_+))','(+o+)','(°°)','(°-°) (°.°)',
'(°_°)','(°_°>)','(°レ°)','(o|o)','<(｀^´)>','^_^','(°o°)','(^_^)/','(^O^)／','(^o^)／','(^^)/','(≧∇≦)/','(/◕ヮ◕)/','(^o^)丿','∩(·ω·)∩',
'(·ω·)','^ω^','_(._.)_','_(_^_)_','<(_ _)>','<m(__)m>','m(__)m','m(_ _)m','(凸ಠ益ಠ)凸',"('_')",'(/_;)','(T_T)','(;_;)','(;_;','(;_:)','(;O;)'
,'(:_;)','(ToT)','(Ｔ▽Ｔ)',';_;',';-;',';n;',';;','Q.Q','T.T','TnT','QQ','Q_Q',
'(ー_ー)!!','(-.-)','(-_-)','(一一)','(；一_一)','(=_=)','(=^・^=)','(=^・・^=)','=^_^=','(..)','(._.)',
'.o○','○o.','_旦~~','( ^^)','_U~~','( ^^)','☆ミ','☆彡','>°)))彡','(Q))',
'><ヨヨ (°))<<','>°))))彡','<°)))彡','>°))彡','<+','))><<','<*))','>=<','<コ:彡',
'Ｃ:.ミ','~>°)～～～','～°·_·°～','(°°)～','●～*','￣|○',':3ミ','^m^','(・・?','(?_?)','>^_^<','<^!^>',
'^/^','（*^_^*','§^.^§','(^<^)','(^.^)','(^ム^)','(^·^)','(^.^)','(^_^.)','(^_^)','(^^)','(^J^)',
'(*^.^*)','^_^','(#^.^#)','（^—^）','(^^)/~~~','(^_^)/~','(;_;)/~~~','(^.^)/~~~',
'(-_-)/~~~','($··)/~~~','(@^^)/~~~','(T_T)/~~~','(V)o￥o(V)','＼(~o~)／','＼(^o^)／','＼(-o-)／','ヽ(^。^)ノ',
'ヽ(^o^)丿','(*^0^*)','(*_*)','(*_*;','(+_+) (@_@)','(@_@。','(＠_＠;)',
 '＼(◎o◎)／！','(*^^)v','(^^)v','(^_^)v','（’-’*) (＾ｖ＾)','(＾▽＾)','(・∀・)','(´∀`)','(⌒▽⌒）',
 '＼(^o^)／','\(^o^)/','(~o~)','(~_~)','(^^ゞ','ˊ＿>ˋ','(p_-)', '(-_q)','((d[-_-]b))','(-"-)','(ーー゛)',
 '(^_^メ)', '(-_-メ)','(~_~メ)','(－－〆)','(・へ・)','(｀´)'
 , '<`～´>','<`ヘ´>','(ーー;)','(^0_0^)','(＾ｖ＾)', '(＾ｕ＾)','(＾◇＾)','( ^)o(^ )','(^O^)','(^o^)','(^○^)',')^o^(',
 '(*^▽^*)','(￣ー￣)','(￣□￣;)', '°o°','°O°',':O','o_O','o_0', 'o.O','(o.o)','oO','(°◇°)','（ ﾟ Дﾟ)','(*￣m￣)',
 'ヽ(´ー｀)┌','¯\_(ツ)_/¯','¯\(°_o)/¯','(´･ω･`)', '(‘A`)','(づ￣ ³￣)づ','(*^3^)/~☆','(︶｡︶✽)','(-_-) zzz'
 , 'uwu','UwU','OWO','OwO','～°·_·°～', '(°°)～',':3ミ','(´･ω･`)','(`･ω･´)','(｀-´)>', '（　´_ゝ`）','<3']

#ricordarsi di dire che abbiamo aggiunto delle nuove slang word che non c'erano nella lista passsata dalla meo, (non ricordo quali, bisogna confrontare)
##################### SLANG WORD (con aggiunte nuove, come richiesto)#####################
slang_words = {'omg': 'oh my god','afaik': 'as far as i know', 'afk': 'away from keyboard', 'asap': 'as soon as possible', 'atk': 'at the keyboard', 'atm': 'at the moment', 'a3': 'anytime, anywhere, anyplace', 'bak': 'back at keyboard', 'bbl': 'be back later', 'bbs': 'be back soon', 'bfn/b4n': 'bye for now', 'brb': 'be right back', 'brt': 'be right there', 'btw': 'by the way', 'b4n': 'bye for now', 'cu': 'see you', 'cul8r': 'see you later', 'cya': 'see you', 'faq': 'frequently asked questions', 'fc': 'fingers crossed', 'fwiw': 'for what it\'s worth', 'fyi': 'for your information', 'gal': 'get a life', 'gg': 'good game', 'gmta': 'great minds think alike', 'gr8': 'great!', 'g9': 'genius', 'ic': 'i see', 'icq': 'i seek you', 'ilu': 'ilu: i love you', 'imho': 'in my honest opinion', 'imo': 'in my opinion', 'iow': 'in other words', 'irl': 'in real life', 'kiss': 'keep it simple, stupid', 'ldr': 'long distance relationship', 'lmao': 'laugh my a.. off', 'lol': 'laughing out loud', 'ltns': 'long time no see', 'l8r': 'later', 'mte': 'my thoughts exactly', 'm8': 'mate', 'nrn': 'no reply necessary', 'oic': 'oh i see', 'pita': 'pain in the a..', 'prt': 'party', 'prw': 'parents are watching', 'qpsa?': 'que pasa?', 'rofl': 'rolling on the floor laughing', 'roflol': 'rolling on the floor laughing out loud', 'rotflmao': 'rolling on the floor laughing my a.. off','sk8': 'skate', 'stats': 'your sex and age', 'asl': 'age, sex, location', 'thx': 'thank you', 'ttfn': 'ta-ta for now!', 'ttyl': 'talk to you later', 'u': 'you', 'u2': 'you too', 'u4e': 'yours for ever', 'wb': 'welcome back', 'wtf': 'what the f...', 'wtg': 'way to go!', 'wuf': 'where are you from?', 'w8': 'wait...', '7k': 'sick:-d laugher'}

# distiguo uguale per bfn e b4n
# quindi aggiunto un item nuovo alla lista
slang_words["bfn"] = 'bye for now'

##################### PUNTEGGIATURA #####################
puntuaction = ['!', '"', '#', '$', '%', '&', "'", '(', ')', '*', '+', ',', '.','/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_','`', '{', '|', '}', '~', '»', '«', '“', '”', "-", "...","..",".,",",.", "0", "1", "2" ,"3", "4" , "5" , "6" , "7" , "8" , "9", "—", "←", "ah","ha"]
