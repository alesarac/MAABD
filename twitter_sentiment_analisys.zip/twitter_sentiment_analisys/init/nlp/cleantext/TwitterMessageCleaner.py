import json
import os
import re
from typing import List
from operator import itemgetter
import emoji
from nltk.corpus import stopwords

from init.nlp.cleantext.social_media_chars import completeEmoticonsList
from init.nlp.cleantext.social_media_chars import puntuaction



class TwitterMsgCleaner:
    def __init__(self, no_url=True, no_hashtag=True, no_emoji=True, no_emoticon=True, lower=True, no_slang=True,
                 no_punct = True, no_stopwords = True):
        #lists that the pipeline can eventually fill with values
        self.hashtagList = []
        self.emojiList = []
        self.emoticonList = []        #tasks submitted by the user
        self.__no_url = no_url,
        self.__no_hashtag = no_hashtag,
        self.__no_emoji = no_emoji,
        self.__no_emoticon = no_emoticon ,
        self.__lower = lower
        self.__no_slang = no_slang,
        self.__no_punct = no_punct,
        self.__no_stopwords = no_stopwords

    def clearvars(self):
        self.hashtagList = []
        self.emojiList = []
        self.emoticonList = []

    def processUrlUsername(self,tweet_line):
        if self.__no_url:
            # elimina gli URl
            # strip() method returns a copy of the string by removing both the leading and the trailing characters
            tweet_line = re.sub("URL", ' ', tweet_line).strip()
            # elimina gli USERNAME
            tweet_line = re.sub("USERNAME", ' ', tweet_line).strip()
        return tweet_line


    def processHash(self,tweet_line):
        if self.__no_hashtag:
            hashtagList = []
            for word in (tweet_line.split(" ")):
                if str(word).startswith("#"):
                    hashtagList.append(word)
                    tweet_line = tweet_line.replace(word, "")
            self.hashtagList = hashtagList
        return tweet_line

    def processEmoji(self,tweet_line):
        if self.__no_emoji:
            emojiList = []
            for word in tweet_line:
                if emoji.is_emoji(word):
                    emojiList.append(word)
            self.emojiList = emojiList
            tweet_line = emoji.replace_emoji(tweet_line, replace='')
        return tweet_line

    def processEmoticon(self, tweet_line):
        if self.__no_emoticon:
            emoticonList = []
            for emoticon in completeEmoticonsList:  # cerca le emoticon
                if (tweet_line.find(emoticon) != -1):
                    emoticonList.append(emoticon)
            self.emoticonList = emoticonList
            for emoticon in emoticonList:
                tweet_line = tweet_line.replace(emoticon, '')
        return tweet_line

    def processToLower(self,tweet_line):
        if self.__lower:
            return tweet_line.lower()
        else:
            return tweet_line

    def processSlang(self,tweet_line):
        path = os.path.dirname(__file__) + "/resources/slangs.json"
        slang_words = json.load(open(path))
        if self.__no_slang:
            list_tweet_line = list((tweet_line).split(" "))
            count_item = 0
            for word in list_tweet_line:
                if word in slang_words:
                    list_tweet_line[count_item] = slang_words[word]
                count_item += 1
            tweet_line =  ' '.join(list_tweet_line)
        return tweet_line



    def processPunct(self, tokens): # tokens:List[TwitterWord]):
        if self.__no_punct:
            lemmas = [token[0] for token in tokens]
            #Per ogni segno di punteggiatura, cerca se il segno è sottostringa della parola
            #ESEMPIO: lemma: <<<< e carattere '<' contenuto in lista puctuation
            try:
                #check_no_punt = lambda lemma: all([0 if ((lemma is None) or (punt in lemma)) or (re.sub(r'[^\w]', '', lemma) == "") else 1 for punt in puntuaction])
                check_no_punt = lambda lemma: all(
                    [0 if ((lemma is None) or (punt in lemma)) or (re.sub(r'[^\w]', '', lemma) == "") else 1 for punt in
                     puntuaction])
                indexes = [i for i in range(len(lemmas)) if check_no_punt(lemmas[i])]
            except:
                print("WARNING: Unable to remove punctuation in:" , tokens)
                raise
                return tokens
            return list(map(tokens.__getitem__, indexes))
        else:
            return None

    def processStopwords(self, tokens):# tokens:List[TwitterWord]):
        if self.__no_stopwords:
            path = os.path.dirname(__file__) + "/resources/stop_words_english.txt"
            stop_words = set(line.strip() for line in open(path,encoding="utf8"))
            stop = set(stopwords.words('english')).union(stop_words)
            lemmas = [token[0]for token in tokens]
            indexes = [i for i in range(len(lemmas)) if lemmas[i] not in stop]
            return list(map(tokens.__getitem__, indexes))
        else:
            return None

    def removeSpaces(self, messages):
            return messages.replace(" ", "")
        #indexes = [1 if w not in stop else 0 for w in elements ]


""""
TEST_DEBUG
check_no_punt = lambda lemma: all([0 if ((lemma is None) or (punt in lemma)) else 1 for punt in puntuaction])
s = " USERNAME uyy a las 12 am comienza la celebración ! estare despierta para mandarle mi recuerdito ! <3 ----- 05sd "
print(s)
for l in s.split():
    print(l , "->",(check_no_punt(l)))
"""