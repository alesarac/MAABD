import os
from typing import List
import stanza
import torch

torch.device("mps")


from init.nlp.AbstractNLPEvaluator import NLPEvaluator
class StanfordEvaluator(NLPEvaluator):


    directory = os.path.dirname(__file__) + "/stanza_resources/"

    def __init__(self, *args, **kw):
        super().__init__( *args, **kw)  #extends init method of superclass
        tasks = self.__getTasks()
        self.stanza_processor = stanza.Pipeline('en', dir=self.directory, processors=tasks, use_gpu=True)

    def __getTasks(self) -> str:
        tasks = []  # tasks = 'lemma,tokenize,pos,depparse'
        if self.lemmatization:
            tasks.append("lemma")
        if self.pos_tag:
            tasks.append("tokenize")
        if self.pos_tag:
            tasks.append("pos")
        return ",".join(tasks)

    def getName(self):
        return "Stanford"

    def nlp_pipeline(self, message) -> List[str]:
        doc = self.stanza_processor(message)
        return [(word.lemma, word.xpos) for sent in doc.sentences for word in sent.words]

