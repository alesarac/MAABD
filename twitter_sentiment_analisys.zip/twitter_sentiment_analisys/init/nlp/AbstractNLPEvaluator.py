from abc import ABC, abstractmethod
from typing import List

from init.model.TwitterWord import TwitterWord
from init.model.Emoji import Emoji
from init.model.Emoticon import Emoticon
from init.model.Message import Message
from init.nlp.cleantext.TwitterMessageCleaner import TwitterMsgCleaner
from init.nlp.cleantext.social_media_chars import puntuaction


class NLPEvaluator(ABC):
    """
    This abstract class uses template method
    in order to define the skeleton of the pipeline algorithm
    Subclasses are in charge on define the 'real' nlp pipeline
    without caring of pre/post-processing stuff.
    """
    def __init__(self, tokenize=True, pos_tag=True, lemmatization=True, cleaner: TwitterMsgCleaner = None):
        self.tokenize = tokenize,
        self.pos_tag = pos_tag,
        self.lemmatization = lemmatization
        self.cleaner = cleaner

    #METODO DA RIMUOVERE
    def encodeOutput(self, words:List[TwitterWord]):
        message = Message()
        message.words = words
        for emoji_code in self.cleaner.emojiList:
            emoji = Emoji()
            emoji.encode_emoji(emoji_code)
            message.tockens.append(emoji)
        for emoticon_code in self.cleaner.emoticonList:
            message.tockens.append(Emoticon(code=emoticon_code))
        for hashtag_code in self.cleaner.hashtagList:
            message.tockens.append(Emoticon(code=hashtag_code))
        return message

    def preprocessing(self, message) -> str:
        if self.cleaner is None:
            return message
        self.cleaner.clearvars()
        updated_msg = self.cleaner.processUrlUsername(message)  # toglie: URL e USERNAME
        updated_msg = self.cleaner.processHash(updated_msg)  # processa gli hastag per sentimento
        updated_msg = self.cleaner.processEmoji(updated_msg)  # processa le emoji e le emoticon per sentimento
        updated_msg = self.cleaner.processEmoticon(updated_msg)  # processa le emoji e le emoticon per sentimento
        updated_msg = self.cleaner.processToLower(updated_msg)  # porta tutto in lowercase
        updated_msg = self.cleaner.processSlang(updated_msg)
        return updated_msg

    @abstractmethod
    def nlp_pipeline(self, message):
        pass

    @abstractmethod
    def getName(self):
        pass


    def aggregate_words(self, tokens):
        map = dict()
        for tuple in tokens:
            if tuple not in map.keys():
                map[tuple] = 1
            else:
                map[tuple] += 1
        return [(key[0], key[1], value)  for key, value in map.items()]

    """ 
    def aggregate_tockens(self, tokens):
        map = dict()
        for tocken_code in tokens:
            if tocken_code not in map.keys():
                map[tocken_code] = 1
        return [key for key in map.keys()]
    """

    def remove_unrecognized_tokens(self, tokens):
        for token_tuple in list(tokens):  # iterating on a copy since removing will mess things up
            lemma = token_tuple[0]
            if lemma == None:
                tokens.remove(token_tuple)
        return tokens


    def lowecase(self, tokens):
        return [(token[0].lower(),token[1])  for token in tokens]



    def postprocessing(self, words:List[TwitterWord]):
        if self.cleaner is None:
            return words
        words = self.cleaner.processPunct(words)
        words = self.cleaner.processStopwords(words)
        words = self.remove_unrecognized_tokens(words)
        words = self.lowecase(words)
        words = self.aggregate_words(words)
        return words

    # Template method: The template method is a method in a superclass,
    # usually an abstract superclass, and defines the skeleton of an operation
    # in terms of a number of high-level steps.
    def pipeline(self, raw_message):
        #If user hasn't submitted pre/postprocessing tasks
        if self.cleaner is None:
            words = self.nlp_pipeline(raw_message)
            return words
        clean_message = self.preprocessing(raw_message)
        #Invoke abstract method defined in subclasses
        words = self.nlp_pipeline(clean_message)
        words = self.postprocessing(words)
        return words, set(self.cleaner.emojiList), \
               set(self.cleaner.hashtagList), \
               set(self.cleaner.emoticonList)

