from init.model.TwitterWord import TwitterWord
from init.model.Word import Word
from init.nlp.cleantext.social_media_chars import puntuaction
from nltk import word_tokenize, pos_tag, WordNetLemmatizer
from nltk.corpus import wordnet
from init.nlp.AbstractNLPEvaluator import NLPEvaluator


class NLTKEvaluator(NLPEvaluator):
    """
    Mapping between Treebank POS (used by NLTK)
    and Wordnet POS
    """

    def getName(self):
        return "NLTL"

    def get_wordnet_pos(self, word, treebank_tag):
        # ADJ, ADJ_SAT, ADV, NOUN, VERB = "a", "s", "r", "n", "v"
        if treebank_tag.startswith('J'):
            return wordnet.ADJ,"adj"
        elif treebank_tag.startswith('V'):
            return wordnet.VERB,"verb"
        elif treebank_tag.startswith('N'):
            return wordnet.NOUN,"noun"
        elif treebank_tag.startswith('R'):
            return wordnet.ADV,"adv"
        else:
            return None, "none"

    #overriden method
    def nlp_pipeline(self, message):
        tokens = word_tokenize(message)  # tokenizziamo i tweets
        lemmas = []
        pos = [""] * len(tokens)
        if self.pos_tag:
            pos = pos_tag(tokens)  # effettuo POS Tagging
        if self.lemmatization:
            result = []
            lemmatizer = WordNetLemmatizer()
            for i in range(len(tokens)):
                tag_wordnet = "noun"
                p = wordnet.NOUN
                if not pos[i] == "":
                    p, tag_wordnet = self.get_wordnet_pos(tokens[i],pos[i][1])
                if p is not None:
                    lemma = lemmatizer.lemmatize(tokens[i],p)
                    result.append((lemma, tag_wordnet))
            return result
        return
        #[TwitterWord(word=Word(lemma=tokens[i]), pos=self.get_wordnet_pos(tokens[i],pos[i][1])) for i in range(tokens)]


