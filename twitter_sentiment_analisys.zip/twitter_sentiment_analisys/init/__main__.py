from init.init_mongodb import init_db_mongo
from init.init_mysql import init_db_mysql


def main():
    #init_db_mysql.init_process(test_mode=False)
    init_db_mongo.init_process(test_mode=False)
if __name__ == '__main__':
    # execute only if run as the entry point into the program
    main()

