from init.model import Base
from sqlalchemy import Column, Integer, String, CheckConstraint, Table, ForeignKey


"""
Superclass with respect to Emoticon, Emoji, Hashtag...
Single-table inheritance configuration looks much like joined-table inheritance, 
except only the base class specifies __tablename__. 
A discriminator column is also required on the base table 
so that classes can be differentiated from each other.
"""
class TwitterTocken(Base):
    __table_args__ = (
        CheckConstraint(type in {'emoji','emoticon','hashtag'}),
    )
    __tablename__ = 'TwitterTocken'
    id = Column(Integer, primary_key=True)
    code = Column(String)
    type = Column(String)
    __mapper_args__ = {
        "polymorphic_on": type,
        "polymorphic_identity": "TwitterToken",
    }

    def __str__(self):
        return self.code

    def __repr__(self):
        return self.__str__()

# Crea tabellla fittizia per realizzare associazione N-N tra Message e TwitterTocken
association_table = Table(
    "TockenMessage",
    Base.metadata,
    Column("idmessage", ForeignKey("Message.id"), primary_key=True),
    Column("idtocken", ForeignKey("TwitterTocken.id"), primary_key=True),
)