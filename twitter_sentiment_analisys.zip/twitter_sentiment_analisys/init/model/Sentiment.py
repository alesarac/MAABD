from sqlalchemy import Column, Integer, String

from init.model import Base
class Sentiment(Base):
    __tablename__ = 'Sentiment'
    id = Column(Integer, primary_key=True)
    sentiment = Column(String)

    def __str__(self):
        return "[" + str(self.sentiment) + "]"

    def __repr__(self):
        return self.__str__()
