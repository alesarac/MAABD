from sqlalchemy.orm import relationship
from init.model import Base
from sqlalchemy import Column, Integer, String, CheckConstraint, Table, ForeignKey

from init.model.Word import association_table


class LexicalResource(Base):
    __tablename__ = "LexicalResource"
    id = Column(Integer, primary_key=True)
    filename = Column(String)
    idsentiment = Column(Integer, ForeignKey("Sentiment.id"))
    sentiment = relationship("Sentiment")
    words = relationship("Word", secondary=association_table)
    def __str__ (self):
        return "resource-" + str(self.filename) + " in " +  str(self.sentiment)  + "->" + str(self.words)

