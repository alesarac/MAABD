from init.model.TwitterTocken import TwitterTocken


class Hashtag(TwitterTocken):
    __mapper_args__ = {
        "polymorphic_identity": "hashtag",
    }
