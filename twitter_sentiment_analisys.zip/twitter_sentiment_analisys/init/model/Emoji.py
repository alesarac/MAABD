from init.model.TwitterTocken import TwitterTocken


class Emoji(TwitterTocken):
    __mapper_args__ = {
        "polymorphic_identity": "emoji",
    }

    @staticmethod
    def decode_emoji(code):
        return (code
                .encode('ASCII')
                .decode("raw_unicode_escape")
                .encode('utf-16', 'surrogatepass')
                .decode('utf-16')
                )

    @staticmethod
    def encode_emoji(emoji_str):
        return emoji_str.encode('unicode-escape').decode('ASCII')


