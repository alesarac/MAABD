from init.model import Base
from sqlalchemy import Column, Integer, String, CheckConstraint, Table, ForeignKey


class Word(Base):
    __tablename__ = 'Word'
    id = Column(Integer, primary_key=True)
    lemma = Column(String)

    def __str__ (self):
        return "(" + str(self.id) + "," + self.lemma + ")"

    def __repr__(self):
        return self.__str__()

# Crea tabellla fittizia per realizzare associazione N-N tra Message e TwitterTocken
association_table = Table(
    "ResourceWord",
    Base.metadata,
    Column("idword", ForeignKey("Word.id"), primary_key=True),
    Column("idresource", ForeignKey("LexicalResource.id"), primary_key=True),
)