from init.model.TwitterTocken import TwitterTocken


class Emoticon(TwitterTocken):
    __mapper_args__ = {
        "polymorphic_identity": "emoticon",
    }
