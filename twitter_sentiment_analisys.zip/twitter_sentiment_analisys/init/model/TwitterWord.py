from sqlalchemy.orm import relationship, backref
from init.model import Base
from sqlalchemy import Column, Integer, String, CheckConstraint, Table, ForeignKey


class TwitterWord(Base):
    __tablename__ = 'TwitterWord'
    pos = Column(String, primary_key=True) #additional data
    idword = Column(ForeignKey("Word.id"), primary_key=True)
    idmessage = Column(ForeignKey("Message.id"), primary_key=True)
    word = relationship("Word")
    message = relationship("Message", backref=backref("words"))
    freq = Column(Integer)

    def __str__ (self):
        return "(" + self.word.lemma + "," + self.pos + ")"

    def __repr__(self):
        return self.__str__()
