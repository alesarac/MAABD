from sqlalchemy.orm import relationship, backref
from init.model import Base
from sqlalchemy import Column, Integer, String, ForeignKey, Table
from init.model.TwitterTocken import association_table


class Message(Base):
    __tablename__ = 'Message'
    id = Column(Integer, primary_key=True)
    countmsg = Column(Integer)
    idsentiment = Column(Integer, ForeignKey("Sentiment.id"))
    sentiment = relationship("Sentiment", backref=backref('tweets'),order_by=id)
    tockens = relationship("TwitterTocken", secondary=association_table)
    def __str__ (self):
        return "msg-" + str(self.countmsg) + " in " +  str(self.sentiment)  + "->" + str(self.words) + str(self.tockens)

